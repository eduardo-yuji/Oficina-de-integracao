# Descrição das fases

Nesta seção cada grupo deve editar este arquivo, criando uma subseção onde deve descrever brevemente como será sua fase.

## Fase Grupo A

Descrição da fase do **Grupo A**. 

...

